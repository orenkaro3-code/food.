// Shared menu, API helpers and alert sound for all pages.
window.MENU = [
  { id: "sand", name: "כריכים", sub: "על לחם טרי", color: "#e8742f", items: [
    { id: "egg", n: "כריך ביצה אלפרדו", d: "ביצה, רוטב אלפרדו וחמאה", e: "🥪", star: 1 },
    { id: "tuna", n: "כריך טונה אבוקדו", d: "טונה, אבוקדו וחמאה", e: "🥑", star: 1 } ] },
  { id: "pasta", name: "פסטות", sub: "מהסיר לצלחת", color: "#f2c14e", items: [
    { id: "cream", n: "פסטה שמנת", d: "רוטב שמנת קרמי", e: "🍝" },
    { id: "rosa", n: "פסטה רוזה", d: "שמנת ועגבניות", e: "🍝", star: 1 } ] },
  { id: "eggs", name: "ביצים", sub: "על המחבת", color: "#d9b26a", items: [
    { id: "omelet", n: "חביתה / הומלט", d: "חביתה טרייה מהמחבת", e: "🍳" } ] },
  { id: "falafel", name: "פלאפל וסיגרים", sub: "מהטיגון", color: "#7d8b4a", items: [
    { id: "cigars", n: "סיגרים", d: "סיגרים פריכים", e: "🌯" },
    { id: "fplate", n: "מנה פלאפל", d: "מנת פלאפל מלאה", e: "🧆" },
    { id: "fpita", n: "פיתה פלאפל", d: "כדורי פלאפל בפיתה", e: "🥙", star: 1 },
    { id: "fonly", n: "פלאפל בלבד", d: "כדורי פלאפל עם חומוס בצד", e: "🧆", tag: "חומוס בצד" } ] },
  { id: "cold", name: "שתייה קרה", sub: "מהמקרר", color: "#5fa8c9", items: [
    { id: "mango", n: "מים בטעם מנגו", d: "", e: "🥭" },
    { id: "grape", n: "מים בטעם ענבים", d: "", e: "🍇" },
    { id: "water", n: "מים", d: "", e: "💧" } ] },
  { id: "hot", name: "שתייה חמה", sub: "מהמכונה", color: "#a0673f", items: [
    { id: "esp", n: "אספרסו", d: "", e: "☕" },
    { id: "lungo", n: "קפה לונגו", d: "", e: "☕" },
    { id: "latte", n: "הפוך", d: "", e: "☕", star: 1 },
    { id: "turk", n: "קפה טורקי", d: "", e: "☕" } ] },
];
window.ITEMS = {};
MENU.forEach(c => c.items.forEach(i => { i.cat = c; ITEMS[i.id] = i; }));
window.TABLES = [1, 2, 3];

window.STATUS = {
  new: { t: "חדשה", c: "var(--accent)" },
  cooking: { t: "בהכנה", c: "var(--accent2)" },
  ready: { t: "מוכנה להגשה", c: "var(--ok)" },
  served: { t: "הוגשה", c: "var(--muted)" },
  closed: { t: "שולחן נסגר", c: "var(--muted)" },
};

window.api = async (path, body) => {
  const r = await fetch(path, body
    ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }
    : { cache: "no-store" });
  const j = await r.json().catch(() => ({ error: "שגיאת רשת" }));
  if (!r.ok || j.error) throw new Error(j.error || "שגיאה");
  return j;
};

window.esc = s => String(s ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
window.ago = ms => { const m = Math.floor(ms / 60000); return m < 1 ? "עכשיו" : m < 60 ? `לפני ${m} דק׳` : `לפני ${Math.floor(m / 60)} שע׳`; };

// Alert sound (browsers allow sound only after the first tap on the page)
let actx = null;
window.unlockSound = () => {
  try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); actx.resume(); } catch {}
};
window.beep = (kind = "order") => {
  if (!actx) return;
  const notes = kind === "call" ? [988, 740, 988, 740] : kind === "ready" ? [660, 880] : [880, 1175, 1568];
  notes.forEach((f, i) => {
    const o = actx.createOscillator(), g = actx.createGain(), t = actx.currentTime + i * 0.18;
    o.type = "sine"; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.5, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    o.connect(g).connect(actx.destination); o.start(t); o.stop(t + 0.17);
  });
  try { navigator.vibrate && navigator.vibrate(kind === "call" ? [200, 100, 200, 100, 200] : [150, 80, 150]); } catch {}
};

// Staff devices: once a phone opened the waiter page, scanning a table QR opens that table in the waiter page.
window.isStaff = () => { try { return localStorage.getItem("staff") === "1"; } catch { return false; } };
window.setStaff = v => { try { v ? localStorage.setItem("staff", "1") : localStorage.removeItem("staff"); } catch {} };
