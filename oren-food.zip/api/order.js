const { put, getOne, readBody, send, newId, TABLES } = require("./_db");

// POST /api/order {table, items:[{id,n,q}], note}  → new order for the kitchen
// GET  /api/order?ids=a,b  → status of a customer's own orders
module.exports = async (req, res) => {
  try {
    if (req.method === "GET") {
      const ids = String(req.query.ids || "").split(",").filter(Boolean).slice(0, 20);
      const list = (await Promise.all(ids.map(id => getOne("orders", id)))).filter(Boolean);
      return send(res, 200, { orders: list });
    }
    if (req.method !== "POST") return send(res, 405, { error: "method" });
    const b = readBody(req);
    const table = Number(b.table);
    if (!TABLES.includes(table)) return send(res, 400, { error: "יש לבחור שולחן 1, 2 או 3." });
    const items = (Array.isArray(b.items) ? b.items : [])
      .map(i => ({ id: String(i.id).slice(0, 20), n: String(i.n || "").trim().slice(0, 60), q: Math.min(20, Math.max(1, parseInt(i.q) || 1)), c: !!i.c }))
      .filter(i => i.n)
      .slice(0, 40);
    if (!items.length) return send(res, 400, { error: "ההזמנה ריקה." });
    const now = Date.now();
    const order = {
      id: newId(), num: Math.floor(100 + Math.random() * 900), table, items,
      note: String(b.note || "").slice(0, 200), status: "new", createdAt: now, updatedAt: now,
    };
    await put("orders", order);
    send(res, 200, { order });
  } catch (e) { send(res, e.status || 500, { error: e.message }); }
};
