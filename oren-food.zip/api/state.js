const { getAll, del, send } = require("./_db");

// GET /api/state  → active orders + open waiter calls (cleans anything older than 24h)
module.exports = async (req, res) => {
  try {
    const now = Date.now(), DAY = 864e5;
    const [orders, calls] = await Promise.all([getAll("orders"), getAll("calls")]);
    const oldO = orders.filter(o => now - o.createdAt > DAY).map(o => o.id);
    const oldC = calls.filter(c => c.done || now - c.createdAt > DAY).map(c => c.id);
    await Promise.all([del("orders", ...oldO), del("calls", ...oldC)]);
    send(res, 200, {
      now,
      orders: orders.filter(o => !oldO.includes(o.id)).sort((a, b) => a.createdAt - b.createdAt),
      calls: calls.filter(c => !oldC.includes(c.id)).sort((a, b) => a.createdAt - b.createdAt),
    });
  } catch (e) { send(res, e.status || 500, { error: e.message }); }
};
